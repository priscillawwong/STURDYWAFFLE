#pragma once
#include "math.h"
#define PI 3.14159265

namespace pwong_M6 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Calculator
	/// </summary>
	public ref class Calculator : public System::Windows::Forms::Form
	{
		double result;//end result
		double number;
		double number2;
		int digit;
		bool input;

	private: System::Windows::Forms::Button^  buttonEqual;
	private: System::Windows::Forms::Button^  buttonCLEAR;
			 int operation;//can be four options

	public:
		Calculator(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			result = number = number2 = digit = 0;
			input = true;
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Calculator()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button7;

	private: System::Windows::Forms::Button^  button2;

	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button8;

	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button6;

	private: System::Windows::Forms::Button^  button9;
	private: System::Windows::Forms::Button^  button0;
	private: System::Windows::Forms::Button^  buttonSIN;
	private: System::Windows::Forms::Button^  buttonPOW;


	private: System::Windows::Forms::Button^  buttonCOS;
	private: System::Windows::Forms::Button^  buttonINV;



	private: System::Windows::Forms::TextBox^  textboxResult;

	protected:
	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;
	
#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button0 = (gcnew System::Windows::Forms::Button());
			this->buttonSIN = (gcnew System::Windows::Forms::Button());
			this->buttonPOW = (gcnew System::Windows::Forms::Button());
			this->buttonCOS = (gcnew System::Windows::Forms::Button());
			this->buttonINV = (gcnew System::Windows::Forms::Button());
			this->textboxResult = (gcnew System::Windows::Forms::TextBox());
			this->buttonEqual = (gcnew System::Windows::Forms::Button());
			this->buttonCLEAR = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(17, 70);
			this->button1->Margin = System::Windows::Forms::Padding(4);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(100, 30);
			this->button1->TabIndex = 0;
			this->button1->Text = L"1";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Calculator::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(140, 70);
			this->button2->Margin = System::Windows::Forms::Padding(4);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(100, 30);
			this->button2->TabIndex = 1;
			this->button2->Text = L"2";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Calculator::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(263, 70);
			this->button3->Margin = System::Windows::Forms::Padding(4);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(100, 30);
			this->button3->TabIndex = 2;
			this->button3->Text = L"3";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Calculator::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(17, 109);
			this->button4->Margin = System::Windows::Forms::Padding(4);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(100, 30);
			this->button4->TabIndex = 3;
			this->button4->Text = L"4";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Calculator::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(140, 109);
			this->button5->Margin = System::Windows::Forms::Padding(4);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(100, 30);
			this->button5->TabIndex = 4;
			this->button5->Text = L"5";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Calculator::button5_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(263, 109);
			this->button6->Margin = System::Windows::Forms::Padding(4);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(100, 30);
			this->button6->TabIndex = 5;
			this->button6->Text = L"6";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Calculator::button6_Click);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(17, 149);
			this->button7->Margin = System::Windows::Forms::Padding(4);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(100, 30);
			this->button7->TabIndex = 6;
			this->button7->Text = L"7";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Calculator::button7_Click);
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(140, 149);
			this->button8->Margin = System::Windows::Forms::Padding(4);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(100, 30);
			this->button8->TabIndex = 7;
			this->button8->Text = L"8";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &Calculator::button8_Click);
			// 
			// button9
			// 
			this->button9->Location = System::Drawing::Point(263, 149);
			this->button9->Margin = System::Windows::Forms::Padding(4);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(100, 30);
			this->button9->TabIndex = 8;
			this->button9->Text = L"9";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &Calculator::button9_Click);
			// 
			// button0
			// 
			this->button0->Location = System::Drawing::Point(140, 186);
			this->button0->Margin = System::Windows::Forms::Padding(4);
			this->button0->Name = L"button0";
			this->button0->Size = System::Drawing::Size(100, 30);
			this->button0->TabIndex = 9;
			this->button0->Text = L"0";
			this->button0->UseVisualStyleBackColor = true;
			this->button0->Click += gcnew System::EventHandler(this, &Calculator::button0_Click);
			// 
			// buttonSIN
			// 
			this->buttonSIN->Location = System::Drawing::Point(17, 248);
			this->buttonSIN->Margin = System::Windows::Forms::Padding(4);
			this->buttonSIN->Name = L"buttonSIN";
			this->buttonSIN->Size = System::Drawing::Size(79, 30);
			this->buttonSIN->TabIndex = 10;
			this->buttonSIN->Text = L"SIN";
			this->buttonSIN->UseVisualStyleBackColor = true;
			this->buttonSIN->Click += gcnew System::EventHandler(this, &Calculator::buttonSIN_Click);
			// 
			// buttonPOW
			// 
			this->buttonPOW->Location = System::Drawing::Point(192, 248);
			this->buttonPOW->Margin = System::Windows::Forms::Padding(4);
			this->buttonPOW->Name = L"buttonPOW";
			this->buttonPOW->Size = System::Drawing::Size(80, 30);
			this->buttonPOW->TabIndex = 11;
			this->buttonPOW->Text = L"POW^";
			this->buttonPOW->UseVisualStyleBackColor = true;
			this->buttonPOW->Click += gcnew System::EventHandler(this, &Calculator::buttonPOW_Click);
			// 
			// buttonCOS
			// 
			this->buttonCOS->Location = System::Drawing::Point(104, 248);
			this->buttonCOS->Margin = System::Windows::Forms::Padding(4);
			this->buttonCOS->Name = L"buttonCOS";
			this->buttonCOS->Size = System::Drawing::Size(80, 30);
			this->buttonCOS->TabIndex = 12;
			this->buttonCOS->Text = L"COS";
			this->buttonCOS->UseVisualStyleBackColor = true;
			this->buttonCOS->Click += gcnew System::EventHandler(this, &Calculator::buttonCOS_Click);
			// 
			// buttonINV
			// 
			this->buttonINV->Location = System::Drawing::Point(280, 248);
			this->buttonINV->Margin = System::Windows::Forms::Padding(4);
			this->buttonINV->Name = L"buttonINV";
			this->buttonINV->Size = System::Drawing::Size(81, 30);
			this->buttonINV->TabIndex = 13;
			this->buttonINV->Text = L"INV";
			this->buttonINV->UseVisualStyleBackColor = true;
			this->buttonINV->Click += gcnew System::EventHandler(this, &Calculator::buttonINV_Click);
			// 
			// textboxResult
			// 
			this->textboxResult->Location = System::Drawing::Point(17, 16);
			this->textboxResult->Margin = System::Windows::Forms::Padding(4);
			this->textboxResult->Name = L"textboxResult";
			this->textboxResult->ReadOnly = true;
			this->textboxResult->Size = System::Drawing::Size(341, 24);
			this->textboxResult->TabIndex = 14;
			// 
			// buttonEqual
			// 
			this->buttonEqual->Location = System::Drawing::Point(192, 286);
			this->buttonEqual->Margin = System::Windows::Forms::Padding(4);
			this->buttonEqual->Name = L"buttonEqual";
			this->buttonEqual->Size = System::Drawing::Size(167, 47);
			this->buttonEqual->TabIndex = 15;
			this->buttonEqual->Text = L"=";
			this->buttonEqual->UseVisualStyleBackColor = true;
			this->buttonEqual->Click += gcnew System::EventHandler(this, &Calculator::buttonEqual_Click);
			// 
			// buttonCLEAR
			// 
			this->buttonCLEAR->Location = System::Drawing::Point(17, 286);
			this->buttonCLEAR->Margin = System::Windows::Forms::Padding(4);
			this->buttonCLEAR->Name = L"buttonCLEAR";
			this->buttonCLEAR->Size = System::Drawing::Size(167, 47);
			this->buttonCLEAR->TabIndex = 16;
			this->buttonCLEAR->Text = L"CLEAR";
			this->buttonCLEAR->UseVisualStyleBackColor = true;
			this->buttonCLEAR->Click += gcnew System::EventHandler(this, &Calculator::buttonCLEAR_Click);
			// 
			// Calculator
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 17);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->ClientSize = System::Drawing::Size(379, 341);
			this->Controls->Add(this->buttonCLEAR);
			this->Controls->Add(this->buttonEqual);
			this->Controls->Add(this->textboxResult);
			this->Controls->Add(this->buttonINV);
			this->Controls->Add(this->buttonCOS);
			this->Controls->Add(this->buttonPOW);
			this->Controls->Add(this->buttonSIN);
			this->Controls->Add(this->button0);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button1);
			this->Font = (gcnew System::Drawing::Font(L"Source Code Pro", 7.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Margin = System::Windows::Forms::Padding(4);
			this->Name = L"Calculator";
			this->Text = L"C A L C U L A T O R";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

//button1 on click
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 1;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button2 on click
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 2;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button3 on click
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 3;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button4 on click
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 4;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button5 on click
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 5;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button6 on click
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 6;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button7 on click
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 7;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button8 on click
private: System::Void button8_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 8;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button9 on click
private: System::Void button9_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 9;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//button0 on click
private: System::Void button0_Click(System::Object^  sender, System::EventArgs^  e)
{
	digit = 0;
	if (input == true)
	{
		number *= 10;
		number += digit;
		textboxResult->Text = number.ToString();
	}
	else
	{
		number2 *= 10;
		number2 += digit;
		textboxResult->Text = number2.ToString();
	}
}

//SIN on click
private: System::Void buttonSIN_Click(System::Object^  sender, System::EventArgs^  e)
{
	input = false;
	operation = 0;
	textboxResult->Text = L"SIN(" + number.ToString() + L")";
}

//COS on click
private: System::Void buttonCOS_Click(System::Object^  sender, System::EventArgs^  e)
{

	input = false;
	operation = 1;
	textboxResult->Text = L"COS(" + number.ToString() + L")";
}

//POW on click
private: System::Void buttonPOW_Click(System::Object^  sender, System::EventArgs^  e)
{

	input = false;
	operation = 2;
	textboxResult->Text = number.ToString() + L"^";
}

//INV on click
private: System::Void buttonINV_Click(System::Object^  sender, System::EventArgs^  e)
{

	input = false;
	operation = 3;
	textboxResult->Text = L"INV(" + number.ToString() + L")";

}

//EQUALS on click
private: System::Void buttonEqual_Click(System::Object^  sender, System::EventArgs^  e)
{

	//sine
	if (operation == 0)
	{
		result = sin(number * PI / 180.0);
	}
	//cosine
	if (operation == 1)
	{
		result = cos(number * PI / 180.0);
	}
	//power
	if (operation == 2)
	{
		result = pow(number, number2);
	}
	//inverse
	if (operation == 3)
	{
		result = number*(-1);
	}

	input = true;
	number = number2 = 0;

	textboxResult->Text = result.ToString();
}

//CLEAR on click
private: System::Void buttonCLEAR_Click(System::Object^  sender, System::EventArgs^  e)
{
	textboxResult->Text = L"0";
}
};
}
