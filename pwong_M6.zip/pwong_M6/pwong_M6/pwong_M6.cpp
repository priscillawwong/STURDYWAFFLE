

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//TITLE: ASSIGNMENT M6 - GUI CALCULATOR

//AUTHOR: PRISCILLA WONG 100997548

//OBJECTIVE: to explore GUI applications using Windows Forms to design a simple calculator

//O B J E C T  D E S C R I P T I O N: ----------------------------------------------------------------------------------------------------------------
//Variables: 
//---------> double result: end result
//---------> double number : the first number entered
//---------> double number2: the second number entered
//---------> int digit : each individual digit in the number entered
//---------> bool input : a true or false statement to change between number and number2
//---------> int operation: 0 to 3 (different numbers assigned to the four operations)

//Functions:
//USER INPUT NUMBERS
//digit is set to the number of the button
//---------> if loop
//______________input == true : to set the number to the first number entered
//------------------> multiply the entered digit by 10 each new time its entered to add the digit beside the first one (digit's 10s value)
//------------------> print number in textbox
//______________input == false : to set the number to the second number entered
//------------------> multiply the entered digit by 10 each new time its entered to add the digit bside the first one
//------------------> print number in textbox

//OPERATIONS
//________On Click
//-----------------> the corresponding operation input is set to false
//-----------------> the operation variable is set to a number between 0 and 3 to signify the type of operation
//-----------------> print operation in textbox

//EQUALS
//_______If loop
//-----------------> Operation selected by user & set by Click event is performed
//-----------------> input is set back to true
//-----------------> number and number2 are set back to 0;
//-----------------> result is sent to textbox & printed

//CLEAR
//sets textbox back to 0

//----------------------------------------------------------------------------------------------------------------------------------------------------
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// pwong_M6.cpp : main project file.
#include "stdafx.h"
#include "math.h"       //for trig functions
#include "Calculator.h" //calculator form

using namespace System;
using namespace pwong_M6;

int main(array<System::String ^> ^args)
{
    Console::WriteLine(L"START CALCULATING");

	Calculator c;
	c.ShowDialog();

    return 0;
}
